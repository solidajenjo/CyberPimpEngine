# DraconisEngine

Game Engine based on OpenGL 3.3 & SDL.

Uses DeVIL, Assimp & IMGui.

Developed by Rubén Ajenjo Rodriguez for the UPC Master degree of videogame development.

Repository: https://github.com/solidajenjo/DraconisEngine

Disclaimer: No programmers were harmed in the making of this engine.
